define([
	"dojo/_base/declare",
	"dojo/Deferred",
	"dijit/_WidgetBase",
	"dijit/_TemplatedMixin",
	"dijit/_WidgetsInTemplateMixin",
	"dijit/form/Button",
	"dijit/form/Form",

	"idx/form/TextBox",
	"idx/dialogs",

	"dojo/text!./templates/ConfigForm.html"
], function(declare, Deferred, _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin,
	Button, Form, TextBox, dialogs, template) {

	return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
		templateString: template,

		postCreate: function() {
			this.firstNameField.set("regExp", "^[A-Z].*");
			this.firstNameField.set("invalidMessage", "First name must start with a capital letter.")

			this.firstNameField.on("keyup",this._updateFullNameField.bind(this));
			this.lastNameField.on("keyup",this._updateFullNameField.bind(this));

			this.configForm.on("submit", function(evt) {
				evt.preventDefault();
				if (this.configForm.validate()) {
					var formValues = this.configForm.get("value");
					this._submitData(formValues);
				}
			}.bind(this));
		},

		_updateFullNameField: function() {
			var fullName = this.firstNameField.get("value") + " " + 
				this.lastNameField.get("value");

			this.fullNameField.set("value", fullName);
		},

		_submitData: function(formData) {
			dialogs.showProgressDialog();
			this._fakeXhrRequest(formData).then(
				function success(response) {
					dialogs.hideProgressDialog();
					dialogs.info("Form data posted successfully!");
				},
				function failed(failure) {
					dialogs.hideProgressDialog();
					dialogs.error(failure.message);
				}
			);
		},

		_fakeXhrRequest: function(formData) {
			var deferred = new Deferred();

			setTimeout(function() {
				if (Math.round(Math.random())) {
					//Success!
					deferred.resolve({success: true})
				} else {
					//Failed
					deferred.reject({success: false, message: "Request failed"});
				}
			}, 1200);

			return deferred.promise;
		}
	});
});